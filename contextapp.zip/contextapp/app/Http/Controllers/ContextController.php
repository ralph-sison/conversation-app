<?php

namespace App\Http\Controllers;

use App\Models\Context;
use Illuminate\Http\Request;
use Illuminate\Support\Str;

class ContextController extends Controller
{
    // retries a list of contexts
    public function index()
    {
        return Context::all();
    }

    public function store(Request $request)
    {
        // we need to validate the request data first
        $validatedData = $request->validate([
            'conversation_id' => 'required|string',
            'message' => 'required|string',
            'name' => 'nullable|string' // optional name
        ]);

        // if valid
        if ($validatedData) {
            $responseMsg = '';

            $contexts = Context::all();
            foreach ($contexts as $context) {
                // check if the request message contains a word on the context table
                if (Str::contains(Str::lower($request->message), Str::lower($context->message))) {
                    // if name is supplied, the response will be modified to include the name for a more dynamic approach
                    $responseMsg = $request->name ? Str::substrReplace($context->response, " $request->name.", strlen($context->response)-1) : $context->response;
                    break; // we break the loop because of the constraint where first context detected takes priority
                }
            }

            if (Str::of($responseMsg)->trim()->isEmpty()) { // if request message is not on the context table
                $responseMsg = $request->name ? "Sorry, I don't understand, $request->name." : "Sorry, I don't understand.";
            }

            // build the response
            $response = [
                'response_id' => $request->conversation_id,
                'response' => $responseMsg
            ];

            return response()->json($response, 201);
        }
    }
}
