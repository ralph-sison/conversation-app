<?php

namespace Tests\Feature;

use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Foundation\Testing\WithFaker;
use Tests\TestCase;

class ContextAppTest extends TestCase
{
    public function testRequireConversationIdAndMessage()
    {
        $headers = [
            'Content-Type' => 'application/json',
            'Accept' => 'application/json'
        ];

        $this->json('POST', 'api/message', $headers)
            ->assertStatus(422)
            ->assertJson([
                "message" => "The given data was invalid.",
                "errors" => [
                    "conversation_id" => ["The conversation id field is required."],
                    "message" => ["The message field is required."]
                ]
            ]);
    }

    public function testConversationIdAndMessageAreStrings()
    {
        $payload = [
            'conversation_id' => 123,
            'message' => 111
        ];

        $headers = [
            'Content-Type' => 'application/json',
            'Accept' => 'application/json'
        ];

        $this->json('POST', 'api/message', $payload, $headers)
            ->assertStatus(422)
            ->assertJson([
                "message" => "The given data was invalid.",
                "errors" => [
                    "conversation_id" => ["The conversation id must be a string."],
                    "message" => ["The message must be a string."]
                ]
            ]);
    }

    public function testResponsesAreCorrect()
    {
        $headers = [
            'Content-Type' => 'application/json',
            'Accept' => 'application/json'
        ];

        $payload = [
            'conversation_id' => 'abcd123',
            'message' => "Hello, I'm John",
        ];

        $this->json('POST', 'api/message', $payload, $headers)
            ->assertStatus(201)
            ->assertJson([
                'response_id' => $payload['conversation_id'],
                'response' => "Welcome to StationFive."
            ]);
    }

    public function testAllContextsAreListed()
    {
        $headers = [
            'Content-Type' => 'application/json',
            'Accept' => 'application/json'
        ];

        $this->json('GET', 'api/contexts', [], $headers)
            ->assertStatus(200)
            ->assertJson([
                [
                    'message' => 'Hello',
                    'response' => "Welcome to StationFive."
                ],
                [
                    'message' => 'Hi',
                    'response' => "Welcome to StationFive."
                ],
                [
                    'message' => 'Goodbye',
                    'response' => "Thank you, see you around."
                ],
                [
                    'message' => 'bye',
                    'response' => "Thank you, see you around."
                ]
            ])
            ->assertJsonStructure([
                '*' => ['id', 'created_at', 'updated_at']
            ]);
    }
}
