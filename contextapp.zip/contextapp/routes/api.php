<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::middleware('auth:sanctum')->get('/user', function (Request $request) {
    return $request->user();
});

// NOTE : In a fresh install of Laravel 8, there is no namespace prefix being applied to our route groups that your routes are loaded into.
// You would have to use the Fully Qualified Class Name for your Controllers when referring to them in your routes when not using the namespace prefixing.

// context routes
Route::get('contexts', 'App\Http\Controllers\ContextController@index');
Route::post('message', 'App\Http\Controllers\ContextController@store');
