<?php

namespace Database\Seeders;

use App\Models\Context;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Log;

class ContextSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        Log::debug('Context Seeder: Start seed.');

        $contextArr = $this->data();

        foreach ($contextArr as $context) {
            Context::updateOrcreate($context);
        }

        Log::debug('Context Seeder: Seed complete.');
    }

    private function data()
    {
        return [
            [
                'message' => 'Hello',
                'response' => "Welcome to StationFive."
            ],
            [
                'message' => 'Hi',
                'response' => "Welcome to StationFive."
            ],
            [
                'message' => 'Goodbye',
                'response' => "Thank you, see you around."
            ],
            [
                'message' => 'bye',
                'response' => "Thank you, see you around."
            ]
        ];
    }
}
