<?php

namespace Database\Factories;

use Illuminate\Database\Eloquent\Factories\Factory;
use Illuminate\Support\Str;

class ContextFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array
     */
    public function definition()
    {
        return [
            'conversation_id' => Str::random(7),
            'message' => $this->faker->randomElement(['Hello there', 'hi there', 'goodbye now', 'Bye now', Str::random(5)]),
            'name' => $this->faker->randomElement(['', $this->faker->name()])
        ];
    }
}
